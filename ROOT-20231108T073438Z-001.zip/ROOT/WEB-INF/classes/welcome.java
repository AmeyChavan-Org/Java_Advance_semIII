import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class welcome extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		try
		{
			res.setContentType("text/html");
			PrintWriter pw = res.getWriter();
			HttpSession session = req.getSession(false);
			String n = (String)session.getAttribute("name");
			pw.print("Welcome "+n);
			pw.println("<br><a href=login.html>Go Back</a>");
			pw.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
