import java.io.*;
import java.net.*;

/**
 * a5q1Client
 */
public class a5q1Client {

    public static void main(String[] args) throws IOException,UnknownHostException 
    {
        Socket s=new Socket("localhost",50710);
        System.out.println("Connected to server");
	

    //    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

        String line;

        InputStream is=s.getInputStream();
        DataInputStream dis=new DataInputStream(is);

        OutputStream os=s.getOutputStream();
		DataOutputStream dos=new DataOutputStream(os);

        while(true)
        {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
            line=br.readLine();
            if(line.equals("END"))
            {
                dos.writeUTF(line);
                break;
            }
            else    
                dos.writeUTF(line);
		System.out.println(dis.readUTF());
        }
	 System.out.println("CLIENT is CLOSED...");
        s.close();
       
    }
}
