import java.io.*;
import java.net.*;

class a5q1Server
{
    public static void main(String[] args) throws IOException,UnknownHostException
    {
        ServerSocket ss=new ServerSocket(50710);
        System.out.println("Server has started & waiting for client to connect ...");
        Socket s=ss.accept();
        System.out.println("Client is connected");
    

        InputStream is=s.getInputStream();
        DataInputStream dis=new DataInputStream(is);

        OutputStream os=s.getOutputStream();
		DataOutputStream dos=new DataOutputStream(os);

        while(true)
        {
	    String line=dis.readUTF();
            if(line.equals("END"))
                break;
            else
                System.out.println(line);
		dos.writeUTF(line);
        }
	dis.close();
        System.out.println("SERVER is CLOSED...");
	s.close();
    }
}
