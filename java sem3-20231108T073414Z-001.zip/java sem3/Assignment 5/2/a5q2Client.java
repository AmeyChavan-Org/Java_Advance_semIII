import java.net.*;
import java.io.*;

class a5q2Client
{
	public static void main(String args[]) throws Exception
	{
		Socket s = new Socket("localhost",50710);
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("\nEnter file name : ");
		String filename = br.readLine();
		File f = new File(filename);
		while((!(filename.endsWith(".txt"))) ){
		   System.out.print("\nInvalid input ");
		   System.out.print("\nEnter file name : ");
		   filename = br.readLine();
		   f = new File(filename);
		   }
                      while((!(f.exists()))){
                      System.out.print("\nFile does not exist ");
		   System.out.print("\n\nEnter file name : ");
		   filename = br.readLine();
		  f = new File(filename);
	
			}
		
		OutputStream os = s.getOutputStream();
		DataOutputStream dos = new DataOutputStream(os);
		dos.writeUTF(filename);
		
		InputStream is = s.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		
		String line;
		
		//System.out.println("File contents: ");
		try
		{
			while((line=dis.readUTF())!=null)
			{
				System.out.println(line);
			}
		}
		catch(Exception e) 
		{
		}
		
		System.out.println("CLIENT is CLOSED...");
		dos.close();
		dis.close();
		s.close();
	}
}	 	
