import java.net.*;
import java.io.*;

class a5q2Server
{
	public static void main(String args[]) throws Exception
	{
		ServerSocket ss = new ServerSocket(50710);
		System.out.println("Server has started & Waiting for client to connect.");
		
		Socket s = ss.accept();
		System.out.println("\nClient is connected.");
				
		InputStream is = s.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		
		String filename = dis.readUTF();
		File f = new File(filename);

		OutputStream os = s.getOutputStream();
		DataOutputStream dos = new DataOutputStream(os);
		
		String line;
		
				BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
				while((line=br.readLine())!=null)
				{
					dos.writeUTF(line);
				}
			
			
		
		System.out.println("SERVER is CLOSED...");
		dis.close();
		dos.close();
		s.close();
	}
}
		

