import java.net.*;
import java.io.*;

class a5q2Server
{
	public static void main(String args[]) throws Exception
	{
		ServerSocket ss = new ServerSocket(50710);
		System.out.println("Server has started & Waiting for client to connect.");
		
		Socket s = ss.accept();
		System.out.println("\nClient is connected.");
				
		InputStream is = s.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		
		OutputStream os = s.getOutputStream();
		DataOutputStream dos = new DataOutputStream(os);
		
		String filename;
		

		filename  = dis.readUTF();
		File f = new File(filename);
		while((!(filename.endsWith(".txt"))) ){
		   dos.writeUTF("Enter valid file name");
		    filename  = dis.readUTF();
		   }
                      while((!(f.exists()))){
                      dos.writeUTF("file does not exists");

		   filename  = dis.readUTF();

	
			}
			String line;

		
			
			
				BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
				while((line=br.readLine())!=null)
				{
					dos.writeUTF(line);
					break;
				}
			
			
		
		
		
		
		 
		dis.close();
		dos.close();
		
System.out.println("SERVER is CLOSED...");
		s.close();
	}
}
			
		

