import java.io.*;
import java.net.*;

class a5q3Client
{
    public static void main(String[] args) throws IOException,UnknownHostException
    {
        Socket s=new Socket("localhost",50710);
        System.out.println("Connected to server.");

        InputStream in=s.getInputStream();
        DataInputStream din = new DataInputStream(in);

        OutputStream out = s.getOutputStream();
        DataOutputStream dop = new DataOutputStream(out);

        BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
        System.out.println("ENTER A STRING :");
        dop.writeUTF(br.readLine());
        System.out.println(din.readUTF());
    }
}
