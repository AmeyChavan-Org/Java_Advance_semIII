
import java.io.*;
import java.net.*;
class a5q3Server

{
    public static void main(String[] args) throws IOException,UnknownHostException
    {
        ServerSocket ss=new ServerSocket(50710);
        System.out.println("Server is started & waiting for client to connect...");

        Socket s=ss.accept();
        System.out.println("Client is connected");

        InputStream in=s.getInputStream();
        DataInputStream din = new DataInputStream(in);

        OutputStream out = s.getOutputStream();
        DataOutputStream dop = new DataOutputStream(out);

        String String1 = din.readUTF();
        char[] charArray=String1.toCharArray();
        String String2 = "";

        for(int i=(String1.length()-1);i>=0;i--)
        {
            String2 += charArray[i];
        }

        if(String1.equals(String2))
            dop.writeUTF("It is palindrome");
        else
            dop.writeUTF("It is not palindrome");

        System.out.println("SERVER is CLOSED...");
        s.close();
    }
}
