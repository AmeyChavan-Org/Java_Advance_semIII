import java.sql.*;


class employee
{
	public static void main(String args[]) throws SQLException,ClassNotFoundException
	{
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/semIIIca226353","semIIIca226353","");
		System.out.println("Connection Found !!");
		
		try{
			
			Class.forName("com.mysql.cj.jdbc.Driver");

			
			String qry="create table employee(empid int primary key,name varchar(20),salary varchar(20))";
			PreparedStatement ps = conn.prepareStatement(qry);
			ps.executeUpdate(qry);
		   	System.out.println("Table Created !!");
		   }
		  catch(SQLException se)
		   {
				System.out.println(se);			
		   }
		catch(ClassNotFoundException ce)
		{
				System.out.println(ce);		
		}
		finally
		{
				try
				{
					conn.close();
				}
				catch(SQLException se)
				{
					System.out.println(se);	
				}
		}	
	}
}
