
drop table employee;
create table employee(empid int primary key, empname varchar(10), salary int);



