drop table emp;

create table emp(empid integer primary key, empname varchar(20), salary integer);

insert into emp values(1,"ram kashyap",90000); 
