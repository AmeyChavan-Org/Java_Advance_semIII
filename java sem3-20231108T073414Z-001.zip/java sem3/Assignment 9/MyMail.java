import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

public class MyMail
{
	public static void main(String[] args)
	{
		String rec="email226338@localhost.localdomain";
		String sen="semIIIca226361@localhost.localdomain";
		String host="localhost"; //127.0.0.1
		
		Properties prop=System.getProperties();
		prop.setProperty("mail.smtp.host",host);
		Session s=Session.getDefaultInstance(prop);
		try
		{
			MimeMessage msg=new MimeMessage(s);
			msg.setFrom(new InternetAddress(sen));
			msg.addRecipient(Message.RecipientType.TO,new InternetAddress(rec));
			
			msg.setSubject("Text Message");
			msg.setText("Hello,Sharwani here.... how are you");
			Transport.send(msg);
			System.out.println("Message Send Sucessfully");
		}
		catch(Exception me)
		{
			me.printStackTrace();
		}		
	}
}

