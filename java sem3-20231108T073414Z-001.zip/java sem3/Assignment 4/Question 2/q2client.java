import java.net.*;
import java.io.*;


class q2client
{
	public static void main(String args[]) throws UnknownHostException,IOException
	{
		Socket s = new Socket("localhost",50711);
		InputStream is = s.getInputStream();
		DataInputStream dis = new DataInputStream(is);
			
		String msg =dis.readUTF();
                System.out.print(msg+"\n");
		System.out.println("\n");

		dis.close();
		s.close();
	
	}
}
