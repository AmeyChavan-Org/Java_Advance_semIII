import java.net.*;
import java.io.*;
class Ass4q1Client
{
    public static void main(String[] args) throws UnknownHostException,IOException
    {
        Socket s=new Socket("localhost",50710);
        InputStream i = s.getInputStream();
        DataInputStream di =new DataInputStream(i);

	System.out.println(di.readUTF());
	System.out.println(di.readUTF());
	System.out.println(di.readUTF());
        s.close();
    }
}
