import java.net.*;
import java.io.*;

public class Ass4q1
{
	public static void main(String args[]) throws UnknownHostException
	{
		InetAddress iaddr;
		System.out.println("Output of getLocalHost() method = "+InetAddress.getLocalHost());
		iaddr=InetAddress.getByName("localhost");
		System.out.println("Output of getByName() method = "+iaddr);

		InetAddress iaddrAll[]=InetAddress.getAllByName("localhost");
		for(int i=0;i<iaddrAll.length;i++)
		System.out.println("Output of getAllByName() method = "+iaddrAll[i]);
		
		toStringDemo t=new toStringDemo(iaddr.getHostName(),iaddr.getHostAddress());
		System.out.println(t);
	}
}
































/*
class toStringDemo
{
	String hostname,IpAddress;

	toStringDemo(String h,String i)
	{
		hostname=h;
		IpAddress=i;
	}

	public String toString()
	{
		return "Hostname and IpAddress="+hostname+""+IpAddress; 
	}
}
*/


















































/*
class toStringDemo
{
	String hostname,IpAddress;

	toStringDemo(String h,String i)
	{
		hostname=h;
		IpAddress=i;
	}

	public String toString()
	{
		return "Hostname and IpAddress="+hostname+""+IpAddress; 
	}
}
*/
