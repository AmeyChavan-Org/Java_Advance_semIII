import java.net.*;
import java.io.*;
public class Ass4q1Server 
{
    public static void main(String[] args) throws UnknownHostException,IOException
    {
        ServerSocket ss=new ServerSocket(50710);
        System.out.println("Server stared waiting for client...");

        Socket s=ss.accept();
        System.out.println("Client connected");
	
	//InputStream is=s.getInputStream();
	//DataInputStream dis=new DataInputStream(is);

	OutputStream os=s.getOutputStream();
	DataOutputStream dos=new DataOutputStream(os);
	
        dos.writeUTF("Local port :"+s.getLocalPort());
        dos.writeUTF("Inet Address:"+s.getInetAddress());
        dos.writeUTF("Port:"+s.getPort());
	dos.close();
        s.close();


    }
}
