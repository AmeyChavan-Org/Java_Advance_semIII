import java.awt.*;
import java.applet.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class ass23 extends JFrame implements ActionListener
{
	JLabel l1, l2, l3, l4, l5, Head;
	JTextField t,t1, t2, t3, t4;
	JButton b1, b2, b3, b4;
	JFrame f = new JFrame();
	Statement st = null;
	Connection cn = null;
	PreparedStatement ps = null;
	ass23()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://192.168.28.3/semIIIca226361","semIIIca226361","");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
		
		setLayout(new GridLayout(6,0,10,10));
		
		JPanel p3 = new JPanel();
        Head = new JLabel("Product Information", JLabel.CENTER);
        Head.setFont(new Font("", Font.BOLD, 18));
        p3.add(Head);
        add(p3);
		
		JPanel p4 = new JPanel();
		p4.setLayout(new GridLayout(1,2,10,10));
		l1 = new JLabel("Product ID", JLabel.CENTER);
		p4.add(l1);
		t= new JTextField(20);
		p4.add(t);
		t.setEnabled(true);
		add(p4);
		
		JPanel p5 = new JPanel();
		p5.setLayout(new GridLayout(1,2,10,10));
		l3 = new JLabel("Name", JLabel.CENTER);
		p5.add(l3);
		t1= new JTextField(20);
		p5.add(t1);
		t1.setEnabled(true);
		add(p5);
		
		JPanel p6 = new JPanel();
		p6.setLayout(new GridLayout(1,2,10,10));
		l4= new JLabel("Price", JLabel.CENTER);
		p6.add(l4);
		t2= new JTextField(20);
		p6.add(t2);
		t2.setEnabled(true);
		add(p6);
		
		JPanel p7 = new JPanel();
		p7.setLayout(new GridLayout(1,2,10,10));
		l5= new JLabel("Quantity", JLabel.CENTER);
		p7.add(l5);
		t3= new JTextField(20);
		p7.add(t3);
		t3.setEnabled(true);
		add(p7);
		
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(1,4,20,1));
		add(p);
		b1= new JButton("Add");
		b1.addActionListener(this);
		p.add(b1);
		b2= new JButton("Update");
		b2.addActionListener(this);
		b2.setEnabled(false);
		p.add(b2);
		add(p);
		b3= new JButton("Search");
		b3.addActionListener(this);
		p.add(b3);
		b4= new JButton("Exit");
		b4.addActionListener(this);
		p.add(b4);
		
		setSize(400,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JOptionPane.showMessageDialog(null,"Connected to Database","Success",JOptionPane.INFORMATION_MESSAGE);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String cmdSrc = ae.getActionCommand();
		String record = "";
		if(cmdSrc.equals("Add"))
		{
			
			try
			{
				int num = Integer.parseInt(t.getText());;
				String name = t1.getText();
				int price = Integer.parseInt(t2.getText());
				int quantity = Integer.parseInt(t3.getText());
				
				if((t.getText()).isEmpty())
				{
					JOptionPane.showMessageDialog(null,"Product ID can not be null","Warning",JOptionPane.WARNING_MESSAGE);
					t.setText("");
				}
				if(price <= 0 || quantity <= 0)
				{
					JOptionPane.showMessageDialog(null,"Price and Quantity must be greater than zero","Warning",JOptionPane.WARNING_MESSAGE);
					t2.setText("");
					t3.setText("");
				}
				else
				{
					String insertQuery = "insert into product value(?,?,?,?)";
					PreparedStatement stmt = cn.prepareStatement(insertQuery);
					stmt.setInt(1,num);
					stmt.setString(2,name);
					stmt.setInt(3,price);
					stmt.setInt(4,quantity);
					int res = stmt.executeUpdate();
					JOptionPane.showMessageDialog(null,res+" Records Added","Success",JOptionPane.INFORMATION_MESSAGE);
					t.setText("");
					t1.setText("");
					t2.setText("");
					t3.setText("");
					b2.setEnabled(false);
           			b3.setLabel("Search");
				}
			}
			catch(SQLIntegrityConstraintViolationException dup)
			{
				JOptionPane.showMessageDialog(null,"Product already exists","Warning",JOptionPane.WARNING_MESSAGE);
				t.setText("");
				t1.setText("");
				t2.setText("");
				t3.setText("");
			}
			catch (NumberFormatException nfe) 
            {
                JOptionPane.showMessageDialog(null,"Enter valid data","Warning",JOptionPane.WARNING_MESSAGE);
            }
			catch (Exception e) 
            {
                System.out.println(e);
            }
           	 
		}
		
		else if(cmdSrc.equals("Update"))
		{
			try 
            {
                int num = Integer.parseInt(t.getText());
                String name = t1.getText();
                int price = Integer.parseInt(t2.getText());
                int quantity = Integer.parseInt(t3.getText());
    		
                if(!name.isEmpty())
                {
                	String deleteQury = "update product set name=?,price=?,quantity=? where num=?" ;
                	PreparedStatement stmt = cn.prepareStatement(deleteQury); 
                
                	stmt.setString(1,name);
                	stmt.setInt(2,price);
                	stmt.setInt(3,quantity);
                	stmt.setInt(4,num);

                	int res = stmt.executeUpdate();
                	
                	if(res == 0)
                	{
                   		JOptionPane.showMessageDialog(null,"No Records Found","Error",JOptionPane.ERROR_MESSAGE);
                	}
               		else
                	{
                   		JOptionPane.showMessageDialog(null,res+" Records Updated.","Success",JOptionPane.INFORMATION_MESSAGE);
                   		t.setText("");
						t1.setText("");
						t2.setText("");
						t3.setText("");
                	}
                	
            	}
            	else
            	{
            		throw new NumberFormatException();
            	}
            }
            catch(NumberFormatException NFE)
            {
            	JOptionPane.showMessageDialog(null,"Please Fill all the info.","Warning",JOptionPane.WARNING_MESSAGE);
            }
            catch (Exception e) 
            {
                System.out.println(e);
            }
            finally
            {
            	b2.setEnabled(false);
            	b3.setLabel("Search");
            	b1.setEnabled(true);
            	t.setEnabled(true);
            }
		}
			
		else if(cmdSrc.equals("Search"))
		{
			try 
            {
                int num = Integer.parseInt(t.getText());
                               
                String searchQury = "select * from product where num=?";
                PreparedStatement stmt = cn.prepareStatement(searchQury);
                
                stmt.setInt(1,num);

                ResultSet rs = stmt.executeQuery();
                
                if (rs.next() == false)
                {
                    JOptionPane.showMessageDialog(null,"No Records Found","Error",JOptionPane.ERROR_MESSAGE);
                    t.setText("");
					t1.setText("");
					t2.setText("");
					t3.setText("");
                }
                else
                {
                    do
                    {	
                    	b2.setEnabled(true);
                    	b1.setEnabled(false);
                    	b3.setLabel("Clear");
                    	t.setEnabled(false);
                        t.setText(String.valueOf(rs.getInt(1)));
                        t1.setText(rs.getString(2));
                        t2.setText(String.valueOf(rs.getInt(3)));
                        t3.setText(String.valueOf(rs.getInt(4)));
                    }while(rs.next());
                }
            }
            catch(NumberFormatException NFE)
            {
                JOptionPane.showMessageDialog(null,"Please Enter Product Id","Error",JOptionPane.ERROR_MESSAGE);
            }
            catch (Exception e) 
            {
                System.out.println(e);
            }
		}
		else if(cmdSrc.equals("Clear"))
		{
			t.setText("");
			t1.setText("");
			t2.setText("");
			t3.setText("");
			b3.setLabel("Search");
			b2.setEnabled(false);
			b1.setEnabled(true);
			t.setEnabled(true);
		}
		
		else if(cmdSrc.equals("Exit"))
		{
			System.exit(0);		
		}
	}
	public static void main(String args[])
	{
		new ass23();
	}
}
