import java.sql.*;
import java.util.*;

public class ass21
{
	public static void main(String args[]) throws SQLException,ClassNotFoundException
	{
		Connection conn = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/semIIIca226361","semIIIca226361","");
		Scanner sc = new Scanner(System.in);
		String name,c;
		Statement stmt = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		int salary,add,empdelete,id=0,lastemp=0,delid=0,flag=0;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			stmt = conn.createStatement();
			int ch;
			
			
			do{
				System.out.println("\nMenu");
				System.out.println("\n1)Insert into table\n2) Delete from table\n3)Display employee\n4)Exit");
			
				System.out.println("Enter your choice: ");
				ch = sc.nextInt();
				switch(ch)
				{
					case 1: 
						String sql = "Insert into employee values (?,?,?)";
						String sql1 = "select * from employee";
						ps = conn.prepareStatement(sql);
						stmt = conn.createStatement();
						rs = stmt.executeQuery(sql1);
							while(rs.next())
							{
									lastemp = rs.getInt(1);
									id++;
								}
								if(id==0)
								{
									lastemp = 1;
								}
								else
									lastemp += 1;

								System.out.println("Employee Id - "+lastemp);
		
								System.out.println("Enter employee name: ");
								name = sc.next();
			
								System.out.println("Enter salary: ");
								salary = sc.nextInt();
								if(salary <= 0){
									do{
										System.out.println("Enter salary: ");
										salary = sc.nextInt();
									}while(salary<=0);								
								}
						
								ps.setInt(1,lastemp);
								ps.setString(2,name);
								ps.setInt(3,salary);

								int x = ps.executeUpdate();

								if(x>0)
									System.out.println("Record added");
								else
									System.out.println("Record not added");

								
								ps.close();

				
						break;
				
					case 2: 
						System.out.println("Enter employee id: ");
						int eid = sc.nextInt();

						String qry = "select * from employee";
						stmt = conn.createStatement();
						rs = stmt.executeQuery(qry);
						while(rs.next())
						{
							delid = rs.getInt(1);
						
	
							if(eid == delid)
							{
								String qry1 = "delete from employee where empid = '"+eid+"'";
								ps = conn.prepareStatement(qry1);
								ps.executeUpdate();
								System.out.println("Record Deleted!!!!");
								flag = 1;
								break;
							}
						}
						if(flag==0)
						{
							System.out.println("No record found with this id");
						}						
						
						stmt.close();
						break;

					case 3:
						String qry2 = "select * from employee";
						stmt = conn.createStatement();
						rs = stmt.executeQuery(qry2);
						System.out.println("\nEmpid\tEmpname\tSalary");
						while(rs.next())
						{
							System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3));
						}
						//ps.close();
						stmt.close();
						break;
				}
			}
			while(ch<4 && ch>0);		
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		catch(ClassNotFoundException ce)
		{
			System.out.println(ce);
		}
		finally
		{
			try
			{
				conn.close();
			}
			catch(SQLException se)
			{
				System.out.println(se);
			}
		}
	}
}					
