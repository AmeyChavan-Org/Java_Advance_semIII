import java.sql.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;


class ExceptionDemo extends Exception
{
}

public class ass22 implements ActionListener
{
	JLabel l0,l1,l2,l3,l4,l5;
	JTextField t1,t2,t3;
	JMenuBar mb;
	JMenu menu;
	JMenuItem i1,i2,i3,i4,i5,i6;
	JButton b1;
	JFrame f = new JFrame();
	JFrame f1 = new JFrame();
	Connection cn = null;
	PreparedStatement ps = null;
	Statement stmt = null;
	ResultSet rs = null;
	String qry;
	
	public ass22()
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			cn=DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/semIIIca226361","semIIIca226361","");
			JOptionPane.showMessageDialog(f,"Database Connected");
			
			f.setSize(400,200);
			f.setLayout(new GridLayout(5,2));
			
			f1.setSize(400,300);
			f1.setLayout(new GridLayout(3,1));
			
			mb = new JMenuBar();
			menu = new JMenu("Operation");
			
			i1 = new JMenuItem("Insert");
			menu.add(i1);
			i2 = new JMenuItem("Search");
			menu.add(i2);
			i6 = new JMenuItem("Clear");
			menu.add(i6);
			i3 = new JMenuItem("Delete");
			menu.add(i3);
			i4 = new JMenuItem("Display All");
			menu.add(i4);
			i5 = new JMenuItem("Exit");
			menu.add(i5);
			
			mb.add(menu);
			f.add(mb);
			
			l0 = new JLabel("");
			f.add(l0);
			
			l1 = new JLabel("Telephone ",SwingConstants.RIGHT);
			f.add(l1);
				
			l2 = new JLabel("Information");
			f.add(l2);
			
			l3 = new JLabel("Telephone Number");
			f.add(l3);
			t1 = new JTextField(20);
			f.add(t1);
				
			l4 = new JLabel("Name");
			f.add(l4);			
			t2 = new JTextField(20);
			f.add(t2);
				
			l5 = new JLabel("Address");
			f.add(l5);	
			t3 = new JTextField(30);
			f.add(t3);
			
			i1.addActionListener(this);
			i2.addActionListener(this);
			i3.addActionListener(this);
			i4.addActionListener(this);
			i5.addActionListener(this);
			i6.addActionListener(this);
			f.setVisible(true);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		catch(SQLException e)
		{
			JOptionPane.showMessageDialog(f," "+e.getMessage());
		}
		catch(ClassNotFoundException ce) {}
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==i5)
		{
			try
			{
				cn.close();
				JOptionPane.showMessageDialog(f,"Database Disconnected");
				System.exit(0);
			}
			catch(SQLException e)
			{
				JOptionPane.showMessageDialog(f," "+e.getMessage());
			}
		}
		if(ae.getSource()==i1)
		{
			try
			{
				if(!t1.getText().isEmpty() && !t2.getText().isEmpty() && !t3.getText().isEmpty())
				{
		
					try
					{
						if(t1.getText().length()==10 && t1.getText().matches("[0-9]+"))
						{
							
							try
							{
								qry = "insert into Telephone values(?,?,?)";
								ps = cn.prepareStatement(qry);
								ps.setLong(1,Long.valueOf(t1.getText()));
								ps.setString(2,t2.getText());
								ps.setString(3,t3.getText());
								ps.executeUpdate();
								JOptionPane.showMessageDialog(f,"Record Inserted Successfully");
								ps.close();
							}
							catch(SQLIntegrityConstraintViolationException se)
							{
								JOptionPane.showMessageDialog(f,"Telephone number already exist");
							}
							catch(SQLException e)
							{
								JOptionPane.showMessageDialog(f,"Please enter all fields."+e.getMessage());
							}
						}
						else
						{
							throw new ExceptionDemo();
						}
					}
					catch(ExceptionDemo e)
					{
						JOptionPane.showMessageDialog(f,"Please Enter 10 digit positive telephone no.");
					}
				}
				else
				{
					throw new ExceptionDemo();
				}	
			}
			catch(ExceptionDemo ne)
			{
				JOptionPane.showMessageDialog(f,"Please enter all fields");
			}
			finally
			{
				t1.setText(null);
				t2.setText(null);
				t3.setText(null);
			}
		}
		if(ae.getSource()==i2)
		{
			try
			{
				if(t1.getText().length()==10 && t1.getText().matches("[0-9]+") && !t1.getText().isEmpty())
				{
					try
					{
						Long id = Long.valueOf(t1.getText());
						qry = "select Name,Address from Telephone where TelNo = '"+id+"'";
							
						ps = cn.prepareStatement(qry);
						rs = ps.executeQuery();
							
						if(rs.next())
						{
							t2.setText(rs.getString(1));
							t3.setText(rs.getString(2));
						}
						else
						{
							JOptionPane.showMessageDialog(f,"Telephone no. does not exist");
							t1.setText(null);
						}
						ps.close();
					}
					catch(SQLException e)
					{
						JOptionPane.showMessageDialog(f," "+e.getMessage());
					}
				}
				else
				{
					throw new ExceptionDemo();
				}
			}
			catch(ExceptionDemo e)
			{
				JOptionPane.showMessageDialog(f,"Please Enter 10 digit positive telephone no.");
				t1.setText(null);
			}
		}
		if(ae.getSource()==i3)
		{
			try
			{
				if(t1.getText().length()==10 && t1.getText().matches("[0-9]+") && !t1.getText().isEmpty())
				{
					try
					{
						Long id = Long.valueOf(t1.getText());
						 
						int flag=0;
						Long del_id;
						qry = "select * from Telephone";
						
						stmt = cn.createStatement();
						rs = stmt.executeQuery(qry);
						
						while(rs.next())
						{
							del_id = rs.getLong(1);
							if(id.equals(del_id))
							{
								qry = "Delete from Telephone where TelNo = '"+id+"'";
								ps = cn.prepareStatement(qry);
								ps.executeUpdate();
								flag = 1;
								ps.close();
								JOptionPane.showMessageDialog(f,"Record Deleted Successfully");
								break;
							}
						}
						if(flag==0)
							JOptionPane.showMessageDialog(f,"Telephone no. does not exist");
					}
					catch(SQLException e)
					{
						JOptionPane.showMessageDialog(f," "+e.getMessage());
					}
				}
				else
				{
					throw new ExceptionDemo();
				}
			}
			catch(ExceptionDemo e)
			{
				JOptionPane.showMessageDialog(f,"Please Enter 10 digit positive telephone no.");
			}
			finally
			{
				t1.setText(null);
				t2.setText(null);
				t3.setText(null);
			}
		}
		if(ae.getSource()==i4)
		{
			try
			{
				qry = "select * from Telephone";
				stmt = cn.createStatement();
				rs = stmt.executeQuery(qry);
				
				int cnt = 0;
				while(rs.next())
				{
					cnt++;
				}
				
				rs = stmt.executeQuery(qry);
				
				JLabel l6 = new JLabel("Telephone Information",SwingConstants.CENTER);
				f1.add(l6);
				
				String columnData[] = {"TelNo","Name","Address"};
				String rowData[][] = new String[cnt][3];
				
				for(int i=0; rs.next(); i++)
				{
					rowData[i][0] = String.valueOf(rs.getLong(1));
					rowData[i][1] = rs.getString(2);
					rowData[i][2] = rs.getString(3);
				}
				DefaultTableModel tableModel = new DefaultTableModel(rowData,columnData);
				JTable table = new JTable(tableModel);
				
				table.setPreferredScrollableViewportSize(new Dimension(450,100));
				table.setFillsViewportHeight(true);
				
				JScrollPane js = new JScrollPane(table);
				
				f1.add(js); 
				
				JPanel p1 = new JPanel();
				b1 = new JButton("Ok");
				b1.setPreferredSize(new Dimension(100,40));
				p1.add(b1);
				f1.add(p1);
				
				b1.addActionListener(this);
				f1.setVisible(true);
				table.setEnabled(false);
				stmt.close();
			}
			catch(SQLException e)
			{
				JOptionPane.showMessageDialog(f,""+e.getMessage());
			}
		}
		if(ae.getSource()==b1)
		{
			f1.getContentPane().removeAll();
			f1.dispose();
		}
		if(ae.getSource()==i6)
		{
			t1.setText(null);
			t2.setText(null);
			t3.setText(null);
		}						
	}	
	public static void main(String args[])
	{
		new ass22();
	}
}

