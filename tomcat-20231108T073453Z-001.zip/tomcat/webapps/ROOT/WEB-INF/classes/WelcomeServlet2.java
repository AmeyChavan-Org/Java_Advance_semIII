import java.io.*;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class WelcomeServlet extends GenericServlet {

    
    public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the username from the form submission
      String username = (String)session.getAttribute("username");



        // Generate the greeting message
        String greetingMessage = "Hello, " + username + "!<br>";
        

        // Display the greeting and date/time
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Greeting Servlet</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Greeting</h1>");
        out.println("<p>" + greetingMessage + "</p>");
     
        out.println("</body>");
        out.println("</html>");

        out.close();
    }
}



      


