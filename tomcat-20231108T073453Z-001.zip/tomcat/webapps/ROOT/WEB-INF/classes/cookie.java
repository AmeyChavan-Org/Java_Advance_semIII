import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class cookie extends HttpServlet
{
	static int i = 1;
	int total = 0;
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String k = String.valueOf(i);
		Cookie c = new Cookie("visited",k);
		res.addCookie(c);
		int j  = Integer.parseInt(c.getValue());
		if(j==1)
		{
			pw.println("Welcome "+req.getRemoteAddr()+"<br>");
			
		}
		else
		{
			pw.println("Welcome-back "+req.getRemoteAddr()+"<br><br>");
			total += 1;
			pw.println(total);
		}
		i++;
		
	}
}
