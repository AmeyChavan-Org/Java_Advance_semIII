import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get user input

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        HttpSession session = request.getSession();
     PrintWriter out = response.getWriter();
  
out.print("1");
        try {
out.print("2");
            Class.forName("com.mysql.cj.jdbc");
out.print("3");
            Connection connection = DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/semIIIca226300","semIIIca226300","");
out.print("4");
            // Check if the provided login credentials are valid
            String sql = "SELECT * FROM userreg WHERE username = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet result = statement.executeQuery();
             
            if (result.next()) {
                // Valid login, create a session
            
                session.setAttribute("username", username);
                response.sendRedirect("http://localhost:8080/WelcomeServlet"); // Redirect to the welcome page
            } else {
                // Invalid login, redirect to an error page
                response.sendRedirect("file:///exportspg/semIIIca226300/apache-tomcat-8.5.76/webapps/ROOT/displayerror.html");
            }

            result.close();
            statement.close();
            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

