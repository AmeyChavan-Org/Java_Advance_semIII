import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class WelcomeServlet extends HttpServlet {

    
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get the username from the form submission
HttpSession session = request.getSession();
      String username = (String)session.getAttribute("username");



        // Generate the greeting message
        String greetingMessage = "Hello, " + username + "!<br>";
        

        // Display the greeting and date/time
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Greeting Servlet</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Greeting</h1>");
        out.println("<p>" + greetingMessage + "</p>");
     
        out.println("</body>");
        out.println("</html>");

        out.close();
    }
}



      


