import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class WelcomeUser extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the client's IP address
        String ipAddress = request.getRemoteAddr();

        // Check if a cookie named "visited" exists
        boolean isFirstTimeVisitor = true;
        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visited")) {
                    isFirstTimeVisitor = false;
                    break;
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (isFirstTimeVisitor) {
            // Create a cookie to track the visit
            Cookie visitedCookie = new Cookie("visited", "true");
            visitedCookie.setMaxAge(365 * 24 * 60 * 60); // Set cookie expiration to 1 year
            response.addCookie(visitedCookie);

            out.println("<html><body>");
            out.println("<h1>Welcome " + ipAddress + "!</h1>");
            out.println("</body></html>");
        } else {
            out.println("<html><body>");
            out.println("<h1>Welcome back " + ipAddress + "!</h1>");
            out.println("</body></html>");
        }

        out.close();
    }
}

