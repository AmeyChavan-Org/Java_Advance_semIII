import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class A2Q2 extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the client's IP address
        String ipAddress = request.getRemoteAddr();

        // Check if a cookie named "visited" exists
        boolean isFirstTimeVisitor = true;
        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visit")) {
                    isFirstTimeVisitor = false;
                    break;
                }
            }
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (isFirstTimeVisitor) {
            // Create a cookie to track the visit
            Cookie visitCookie1 = new Cookie("visit", "true");
            visitCookie1.setMaxAge(5); 
            response.addCookie(visitCookie1);

            out.println("<html><body>");
            out.println("<h1>Welcome " + ipAddress + "!</h1>");
            out.println("</body></html>");
        } else {
            out.println("<html><body>");
            out.println("<h1>Welcome back " + ipAddress + "!</h1>");
            out.println("</body></html>");
        }

        out.close();
    }
}

