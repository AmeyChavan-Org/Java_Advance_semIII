import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class login extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String uname = req.getParameter("name");
		String pass = req.getParameter("password");
		HttpSession session = req.getSession(true);
		if(checkUser(uname,pass))
		{
			session.setAttribute("name",uname);
			res.sendRedirect("http://localhost:8080/welcome");
		}
		else
		{
			res.sendRedirect("http://localhost:8080/displayerror.html");
		}
	}
	public static boolean checkUser(String uname, String pass)
	{
		boolean st = false;
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection cn=DriverManager.getConnection("jdbc:mysql://192.168.28.3:3306/semIIIca226361","semIIIca226361","");
			PreparedStatement ps = cn.prepareStatement("select * from user where login_name=? and password=?");
			System.out.println("Database Established");
			ps.setString(1,uname);
			ps.setString(2,pass);
			ResultSet rs = ps.executeQuery();
			st = rs.next();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return st;
	}
}
